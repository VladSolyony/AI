using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PNodeInGlobalRegion : MonoBehaviour
{
    public GlobalRegion globalRegion; 

    public int id;
}
