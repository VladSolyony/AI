public enum MinionState
{
   Rotate,
   Move,
   Jump
}
